<?php
namespace App\Test\TestCase\Controller;

use App\Controller\PiController;
use Cake\TestSuite\IntegrationTestCase;

/**
 * App\Controller\PiController Test Case
 */
class PiControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
